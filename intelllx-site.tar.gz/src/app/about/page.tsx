"use client";
import Link from "next/link";
import Image from "next/image";

export default function About() {

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Advanced Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/20 to-cyan-500/20 animate-pulse"></div>
        
        {/* Floating particles */}
        <div className="absolute inset-0">
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>
      </div>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 py-20">
        <div className="max-w-7xl mx-auto text-center">
          {/* Premium Badge */}
          <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8">
            <span className="text-sm font-semibold text-white/90 tracking-wide">About INTELLLX</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-6xl md:text-8xl font-black tracking-tight mb-8 leading-tight">
            <span className="text-white">Purpose-Driven</span>
            <br />
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              AI Innovation
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-white/80 max-w-4xl mx-auto leading-relaxed font-light mb-12">
            We&apos;re a purpose-driven AI company dedicated to building sustainable business success through innovation, integrity, and impact.
          </p>

          {/* Hero Image */}
          <div className="relative max-w-5xl mx-auto">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <Image
                src="/images/about/ai-innovation.jpg"
                alt="AI Innovation - Purpose-driven technology for business success"
                width={1200}
                height={600}
                className="w-full h-auto transition-all duration-700 group-hover:scale-105"
                priority={true}
                placeholder="blur"
                blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAAIAAoDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAhEAACAQMDBQAAAAAAAAAAAAABAgMABAUGIWGRkqGx0f/EABUBAQEAAAAAAAAAAAAAAAAAAAMF/8QAGhEAAgIDAAAAAAAAAAAAAAAAAAECEgMRkf/aAAwDAQACEQMRAD8AltJagyeH0AthI5xdrLcNM91BF5pX2HaH9bcfaSXWGaRmknyJckliyjqTzSlT54b6bk+h0R//2Q=="
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl font-black text-white mb-8 leading-tight">
                Our <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Mission</span>
              </h2>
              <p className="text-xl text-white/80 leading-relaxed font-light mb-8">
                At INTELLLX, we believe that artificial intelligence should serve humanity&apos;s greatest needs. 
                We&apos;re not just building chatbots and websites—we&apos;re creating tools that empower businesses 
                to thrive while maintaining the highest standards of ethical business practices.
              </p>
              <p className="text-lg text-white/70 leading-relaxed font-light">
                Our mission is to democratize AI technology, making it accessible to businesses of all sizes 
                while ensuring that every solution we create adds genuine value to our clients&apos; success.
              </p>
            </div>
            <div className="relative">
              <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-12 border border-white/10">
                <div className="grid grid-cols-2 gap-8">
                  {[
                    { number: "100%", label: "Client Satisfaction" },
                    { number: "24/7", label: "AI Availability" },
                    { number: "3-5x", label: "Lead Increase" },
                    { number: "30", label: "Day ROI" }
                  ].map((stat, index) => (
                    <div key={index} className="text-center">
                      <div className="text-4xl font-black text-white mb-2">{stat.number}</div>
                      <div className="text-white/70 text-sm font-medium">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-8 leading-tight">
              Our <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Values</span>
            </h2>
            <p className="text-xl text-white/70 max-w-4xl mx-auto leading-relaxed font-light">
              The principles that guide everything we do
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: "M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z",
                title: "Innovation",
                description: "We constantly push the boundaries of what&apos;s possible with AI technology, always seeking better ways to solve business challenges."
              },
              {
                icon: "M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z",
                title: "Integrity",
                description: "We operate with complete transparency and honesty, building trust through reliable solutions and ethical business practices."
              },
              {
                icon: "M13 10V3L4 14h7v7l9-11h-7z",
                title: "Impact",
                description: "Every solution we create is designed to make a meaningful difference in our clients&apos; success and growth."
              }
            ].map((value, index) => (
              <div key={index} className="group relative p-10 bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-700 transform hover:scale-105 hover:-translate-y-2">
                <div className="text-center">
                  <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-3xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-500">
                    <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={value.icon} />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-purple-300 transition-colors duration-300">
                    {value.title}
                  </h3>
                  <p className="text-white/80 leading-relaxed group-hover:text-white/95 transition-colors duration-300 font-light text-lg">
                    {value.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="relative">
              <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-12 border border-white/10">
                <h3 className="text-3xl font-bold text-white mb-6">Our Story</h3>
                <p className="text-lg text-white/80 leading-relaxed font-light mb-6">
                  INTELLLX was born from a simple observation: too many businesses were missing out on 
                  opportunities because they couldn&apos;t be available 24/7 to capture leads and engage with prospects.
                </p>
                <p className="text-lg text-white/80 leading-relaxed font-light mb-6">
                  We saw the potential of AI to solve this problem, but we also saw that most AI solutions 
                  were either too complex, too expensive, or too generic to be truly effective.
                </p>
                <p className="text-lg text-white/80 leading-relaxed font-light">
                  So we set out to create something different: AI solutions that are powerful yet simple, 
                  effective yet affordable, and always designed with the specific needs of real businesses in mind.
                </p>
              </div>
            </div>
            <div>
              <h2 className="text-5xl md:text-6xl font-black text-white mb-8 leading-tight">
                Why We <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Exist</span>
              </h2>
              <p className="text-xl text-white/80 leading-relaxed font-light mb-8">
                We believe that every business, regardless of size, should have access to the same 
                powerful AI technology that&apos;s transforming the world&apos;s largest companies.
              </p>
              <div className="space-y-6">
                {[
                  "Democratizing AI technology for businesses of all sizes",
                  "Creating solutions that actually work in the real world",
                  "Building long-term partnerships, not just transactions",
                  "Maintaining the highest standards of ethics and integrity"
                ].map((point, index) => (
                  <div key={index} className="flex items-start gap-4">
                    <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <span className="text-white/80 text-lg leading-relaxed font-light">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-black text-white mb-8 leading-tight">
              Meet the <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Team</span>
            </h2>
            <p className="text-xl text-white/70 max-w-4xl mx-auto leading-relaxed font-light">
              The passionate individuals behind INTELLLX&apos;s success
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                name: "Latauna Eb",
                role: "Founder & CEO",
                description: "Visionary leader with 10+ years in AI and business development, passionate about democratizing technology for small businesses."
              },
              {
                name: "AI Development Team",
                role: "Technical Excellence",
                description: "Expert developers and AI specialists dedicated to creating cutting-edge solutions that deliver real business results."
              },
              {
                name: "Client Success Team",
                role: "Customer Success",
                description: "Dedicated professionals ensuring every client achieves their goals and sees maximum value from our solutions."
              }
            ].map((member, index) => (
              <div key={index} className="group relative p-8 bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-700 transform hover:scale-105 hover:-translate-y-2">
                <div className="text-center">
                  <div className="w-24 h-24 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-500">
                    <span className="text-2xl font-bold text-white">
                      {member.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors duration-300">
                    {member.name}
                  </h3>
                  <p className="text-purple-300 font-semibold mb-4">{member.role}</p>
                  <p className="text-white/80 leading-relaxed group-hover:text-white/95 transition-colors duration-300 font-light">
                    {member.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-16 border border-white/10">
            <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
              Ready to Transform Your Business?
            </h2>
            <p className="text-xl md:text-2xl text-white/80 mb-10 leading-relaxed font-light">
              Join the growing number of businesses using AI to accelerate growth and create lasting impact.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link
                href="/contact"
                className="px-12 py-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl rounded-2xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300"
              >
                <span className="flex items-center gap-3">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  Get in Touch
                </span>
              </Link>
              <Link
                href="/demo"
                className="px-12 py-6 bg-white/10 backdrop-blur-sm text-white font-bold text-xl rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                <span className="flex items-center gap-3">
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.828 14.828a4 4 0 01-5.656 0M9 10h1m4 0h1m-6 4h8m-9-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Request a Demo
                </span>
              </Link>
            </div>
          </div>
        </div>
    </section>
    </div>
  );
}