"use client";
import { site } from "@/config/site";
import StripeCheckoutButton from "@/components/StripeCheckoutButton";
import Link from "next/link";

export default function Pricing() {

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Advanced Background Effects */}
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/20 via-pink-500/20 to-cyan-500/20 animate-pulse"></div>
        
        {/* Floating particles */}
        <div className="absolute inset-0">
          {[...Array(40)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white/20 rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                animationDuration: `${3 + Math.random() * 4}s`
              }}
            />
          ))}
        </div>
      </div>

      <section className="relative mx-auto max-w-7xl px-4 py-20">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8">
            <span className="text-sm font-semibold text-white/90 tracking-wide">Transparent Pricing</span>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black tracking-tight mb-8 leading-tight">
            <span className="text-white">Simple</span>
            <br />
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 bg-clip-text text-transparent">
              Pricing
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-white/70 max-w-4xl mx-auto leading-relaxed font-light">
            Choose the service that fits your business needs. No hidden fees, no surprises.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid lg:grid-cols-2 gap-12 mb-20">
          {/* LeadFlow Chatbot */}
          <div className="group relative p-12 bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-700 transform hover:scale-105 hover:-translate-y-2">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            <div className="relative z-10">
              {/* Header */}
              <div className="text-center mb-10">
                <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 mb-6">
                  <span className="text-sm font-semibold text-purple-300 tracking-wide">🤖 AI Chatbot</span>
                </div>
                
                <h2 className="text-4xl font-black text-white mb-4">LeadFlow Chatbot</h2>
                <p className="text-lg text-white/70 mb-8 leading-relaxed font-light">Your 24/7 AI sales assistant that captures leads and books calls</p>
                
                <div className="text-6xl font-black text-white mb-2">$1,500</div>
                <p className="text-white/60 text-lg mb-4">One-time setup fee</p>
                <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-orange-500/20 to-yellow-500/20 border border-orange-500/30">
                  <span className="text-sm font-semibold text-orange-300">+ $400/month after setup</span>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4 mb-10">
                <h3 className="text-2xl font-bold text-white mb-6">What&apos;s included:</h3>
                {site.pricing[0].setup.items.map((item, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <div className="w-6 h-6 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <span className="text-white/80 text-lg leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>

              {/* CTA Button */}
              <div className="text-center">
                <StripeCheckoutButton className="w-full bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-5 px-8 rounded-2xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300 text-xl">
                  <span className="flex items-center justify-center gap-3">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    Pay Setup Fee - $1,500
                  </span>
                </StripeCheckoutButton>
              </div>
            </div>
          </div>

          {/* Website Development */}
          <div className="group relative p-12 bg-white/5 backdrop-blur-sm rounded-3xl border border-white/10 hover:bg-white/10 transition-all duration-700 transform hover:scale-105 hover:-translate-y-2">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
            <div className="relative z-10">
              {/* Header */}
              <div className="text-center mb-10">
                <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-blue-500/20 to-indigo-500/20 border border-blue-500/30 mb-6">
                  <span className="text-sm font-semibold text-blue-300 tracking-wide">🌐 Web Development</span>
                </div>
                
                <h2 className="text-4xl font-black text-white mb-4">Website Development</h2>
                <p className="text-lg text-white/70 mb-8 leading-relaxed font-light">Custom websites built with modern technologies</p>
                
                <div className="text-6xl font-black text-white mb-2">Starting at $2,000</div>
                <p className="text-white/60 text-lg mb-4">One-time project fee</p>
                <div className="inline-flex items-center px-6 py-3 rounded-full bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30">
                  <span className="text-sm font-semibold text-green-300">Custom pricing available</span>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4 mb-10">
                <h3 className="text-2xl font-bold text-white mb-6">What&apos;s included:</h3>
                {site.pricing[1].setup.items.map((item, i) => (
                  <div key={i} className="flex items-start gap-4">
                    <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                      <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <span className="text-white/80 text-lg leading-relaxed">{item}</span>
                  </div>
                ))}
              </div>

              {/* CTA Buttons */}
              <div className="space-y-4">
                <a
                  href="https://buy.stripe.com/5kQ7sLh1K69dbs7f36aEE02"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-bold py-4 px-8 rounded-2xl shadow-2xl hover:shadow-blue-500/25 transform hover:scale-105 transition-all duration-300 inline-flex items-center justify-center gap-3 text-lg"
                >
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Starter - $2,000
                </a>
                <div className="grid grid-cols-2 gap-4">
                  <a
                    href="https://buy.stripe.com/7sY5kD3aU4150Nt9IMaEE03"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-gradient-to-r from-green-600 to-emerald-600 text-white font-bold py-4 px-4 rounded-2xl shadow-2xl hover:shadow-green-500/25 transform hover:scale-105 transition-all duration-300 text-center text-lg"
                  >
                    Pro - $4,500
                  </a>
                  <a
                    href="https://buy.stripe.com/8x23cv26Q7dh9jZf36aEE04"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold py-4 px-4 rounded-2xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300 text-center text-lg"
                  >
                    Enterprise - $8,000
                  </a>
                </div>
                <Link
                  href="/services/website-development"
                  className="w-full bg-white/10 text-white font-bold py-4 px-8 rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300 text-center text-lg"
                >
                  View All Packages
                </Link>
              </div>
            </div>
          </div>
        </div>

        {/* Combined Services CTA */}
        <div className="text-center mb-20">
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-16 border border-white/10 max-w-5xl mx-auto">
            <h3 className="text-4xl md:text-5xl font-black text-white mb-6">Need Both Services?</h3>
            <p className="text-xl md:text-2xl text-white/80 mb-10 leading-relaxed font-light">
              Get a custom website with integrated LeadFlow Chatbot for maximum lead generation
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link
                href="/contact"
                className="px-12 py-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-xl rounded-2xl shadow-2xl hover:shadow-purple-500/25 transform hover:scale-105 transition-all duration-300"
              >
                Get Custom Quote
              </Link>
              <Link
                href="/demo"
                className="px-12 py-6 bg-white/10 backdrop-blur-sm text-white font-bold text-xl rounded-2xl border border-white/20 hover:bg-white/20 transition-all duration-300"
              >
                Request Demo
              </Link>
            </div>
          </div>
        </div>

        {/* Trust Indicators */}
        <div className="text-center mb-20">
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-12 border border-white/10 max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-white mb-8">Why Choose Our Pricing?</h3>
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z",
                  title: "Transparent",
                  description: "No hidden fees or surprise charges. What you see is what you pay."
                },
                {
                  icon: "M13 10V3L4 14h7v7l9-11h-7z",
                  title: "Fast ROI",
                  description: "Most clients see return on investment within 30 days."
                },
                {
                  icon: "M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 2.25a9.75 9.75 0 100 19.5 9.75 9.75 0 000-19.5z",
                  title: "Scalable",
                  description: "Solutions that grow with your business needs."
                }
              ].map((item, index) => (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
                    </svg>
                  </div>
                  <h4 className="text-xl font-bold text-white mb-2">{item.title}</h4>
                  <p className="text-white/70 leading-relaxed">{item.description}</p>
          </div>
        ))}
            </div>
          </div>
      </div>

        {/* Footer Note */}
        <div className="text-center">
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-12 border border-white/10 max-w-4xl mx-auto">
            <p className="text-lg text-white/80 mb-6 leading-relaxed font-light">
        We operate with integrity and transparency. Custom plans available on request.
      </p>
            <div className="bg-gradient-to-r from-blue-500/10 to-indigo-500/10 border border-blue-500/20 rounded-2xl p-8">
              <p className="text-white/80 leading-relaxed font-light">
                <strong className="text-white">Note:</strong> For LeadFlow Chatbot, after your setup is complete, we&apos;ll work with you to set up the monthly $400 hosting fee. 
                This two-step process ensures all payment methods (including debit cards) work smoothly.
              </p>
            </div>
          </div>
        </div>
    </section>
    </div>
  );
}